Documentation available in http://www.ncbi.nlm.nih.gov/books/NBK1762
